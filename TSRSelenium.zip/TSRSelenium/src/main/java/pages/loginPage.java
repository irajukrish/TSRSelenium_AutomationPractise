package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginPage extends base{
	
	@FindBy(xpath = "//a[@title = 'Log in to your customer account']")
	public static WebElement signin;

	@FindBy(name = "email_create")
	public static WebElement email_textbox;

	@FindBy(id = "uniform-id_gender1")
	public static WebElement title;

	@FindBy(xpath = "//input[@type= 'password']")
	public static WebElement password;
	
	@FindBy(id = "passwd")
	public static WebElement passwd;
	
	@FindBy(id = "SubmitLogin")
	public static WebElement SubmitLogin;
	
	@FindBy(className = "logout")
	public static WebElement SignOut;
	
	@FindBy(id = "email")
	public static WebElement loginUserName;

	public loginPage() {
		PageFactory.initElements(driver, this);
	}

	public static WebElement getSignin() {
		return signin;
	}

	public static void setSignin(WebElement signin) {
		loginPage.signin = signin;
	}
	
	public static WebElement getSignOut() {
		return SignOut;
	}

	public static WebElement getEmail_textbox() {
		return email_textbox;
	}

	public static void setEmail_textbox(WebElement email_textbox) {
		loginPage.email_textbox = email_textbox;
	}

	public static WebElement getTitle() {
		return title;
	}

	public static WebElement getPassword() {
		return password;
	}

	public static void setPassword(WebElement password) {
		loginPage.password = password;
	}	

	public static WebElement getLoginUserName() {
		return loginUserName;
	}

	public static void setLoginUserName(WebElement loginUserName) {
		loginPage.loginUserName = loginUserName;
	}

	public static WebElement getPasswd() {
		return passwd;
	}

	public static void setPasswd(WebElement passwd) {
		loginPage.passwd = passwd;
	}

	public static WebElement getSubmitLogin() {
		return SubmitLogin;
	}

	public static void setSubmitLogin(WebElement submitLogin) {
		SubmitLogin = submitLogin;
	}	

}
