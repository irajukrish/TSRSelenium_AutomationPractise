package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class registrationPage extends base{
	
	@FindBy(xpath = "//a[@title = 'Log in to your customer account']")
	public static WebElement signin;
	
	@FindBy(name = "email_create")
	public static WebElement email_textbox;

	@FindBy(id = "SubmitCreate")
	public static WebElement createAnAccount;

	@FindBy(id = "uniform-id_gender1")
	public static WebElement title;

	@FindBy(id = "customer_firstname")
	public static WebElement fName;

	@FindBy(id = "customer_lastname")
	public static WebElement lName;

	@FindBy(xpath = "//input[@type= 'password']")
	public static WebElement password;
	
	@FindBy(id = "passwd")
	public static WebElement passwd;
	
	@FindBy(id = "SubmitLogin")
	public static WebElement SubmitLogin;
	
	@FindBy(className = "logout")
	public static WebElement SignOut;

	@FindBy(id = "days")
	public static WebElement day;

	@FindBy(id = "months")
	public static WebElement months;

	@FindBy(id = "years")
	public static WebElement years;

	@FindBy(id = "company")
	public static WebElement company;

	@FindBy(id = "address1")
	public static WebElement address;

	@FindBy(id = "address2")
	public static WebElement add2;

	@FindBy(id = "city")
	public static WebElement city;

	@FindBy(id = "postcode")
	public static WebElement postcode;

	@FindBy(id = "other")
	public static WebElement other;

	@FindBy(name = "phone_mobile")
	public static WebElement phone_mobile;

	@FindBy(name = "phone")
	public static WebElement phone;

	@FindBy(name = "submitAccount")
	public static WebElement submitAccount;

	@FindBy(id = "id_state")
	public static WebElement state;
	
	@FindBy(id = "id_country")
	public static WebElement country;

	@FindBy(id = "email")
	public static WebElement loginUserName;
	
	public registrationPage() {
		PageFactory.initElements(driver, this);
	}

	
	public static WebElement getEmail_textbox() {
		return email_textbox;
	}

	public static void setEmail_textbox(WebElement email_textbox) {
		registrationPage.email_textbox = email_textbox;
	}
	
	public static WebElement getPassword() {
		return password;
	}
	
	public static WebElement getSignin() {
		return signin;
	}
	
	public static WebElement getSignOut() {
		return SignOut;
	}

	public static WebElement getCreateAnAccount() {
		return createAnAccount;
	}

	public static void setCreateAnAccount(WebElement createAnAccount) {
		registrationPage.createAnAccount = createAnAccount;
	}

	public static WebElement getTitle() {
		return title;
	}

	public static void setTitle(WebElement title) {
		registrationPage.title = title;
	}

	public static WebElement getfName() {
		return fName;
	}

	public static void setfName(WebElement fName) {
		registrationPage.fName = fName;
	}

	public static WebElement getlName() {
		return lName;
	}

	public static void setlName(WebElement lName) {
		registrationPage.lName = lName;
	}

	public static WebElement getDay() {
		return day;
	}

	public static void setDay(WebElement day) {
		registrationPage.day = day;
	}

	public static WebElement getMonths() {
		return months;
	}

	public static void setMonths(WebElement months) {
		registrationPage.months = months;
	}

	public static WebElement getYears() {
		return years;
	}

	public static void setYears(WebElement years) {
		registrationPage.years = years;
	}

	public static WebElement getCompany() {
		return company;
	}

	public static void setCompany(WebElement company) {
		registrationPage.company = company;
	}

	public static WebElement getAddress() {
		return address;
	}

	public static void setAddress(WebElement address) {
		registrationPage.address = address;
	}

	public static WebElement getAdd2() {
		return add2;
	}

	public static void setAdd2(WebElement add2) {
		registrationPage.add2 = add2;
	}

	public static WebElement getCity() {
		return city;
	}

	public static void setCity(WebElement city) {
		registrationPage.city = city;
	}

	public static WebElement getPostcode() {
		return postcode;
	}

	public static void setPostcode(WebElement postcode) {
		registrationPage.postcode = postcode;
	}

	public static WebElement getOther() {
		return other;
	}

	public static void setOther(WebElement other) {
		registrationPage.other = other;
	}

	public static WebElement getPhone_mobile() {
		return phone_mobile;
	}

	public static void setPhone_mobile(WebElement phone_mobile) {
		registrationPage.phone_mobile = phone_mobile;
	}

	public static WebElement getPhone() {
		return phone;
	}

	public static void setPhone(WebElement phone) {
		registrationPage.phone = phone;
	}

	public static WebElement getSubmitAccount() {
		return submitAccount;
	}

	public static void setSubmitAccount(WebElement submitAccount) {
		registrationPage.submitAccount = submitAccount;
	}

	public static WebElement getState() {
		return state;
	}

	public static void setState(WebElement state) {
		registrationPage.state = state;
	}

	public static WebElement getCountry() {
		return country;
	}

	public static void setCountry(WebElement country) {
		registrationPage.country = country;
	}	

	public static WebElement getLoginUserName() {
		return loginUserName;
	}

	

}
