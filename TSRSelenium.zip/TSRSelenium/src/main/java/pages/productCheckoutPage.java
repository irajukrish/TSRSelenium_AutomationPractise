package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class productCheckoutPage extends base{
	
	@FindBy(xpath = "//a[@title = 'Log in to your customer account']")
	public static WebElement signin;

	@FindBy(name = "email_create")
	public static WebElement email_textbox;

	@FindBy(id = "SubmitCreate")
	public static WebElement createAnAccount;

	@FindBy(xpath = "//input[@type= 'password']")
	public static WebElement password;
	
	@FindBy(id = "passwd")
	public static WebElement passwd;
	
	@FindBy(id = "SubmitLogin")
	public static WebElement SubmitLogin;
	
	@FindBy(className = "logout")
	public static WebElement SignOut;

	@FindBy(xpath = "(//a[@title='T-shirts'])[2]")
	public static WebElement tShirt;	
	
	@FindBy(xpath = "(//a[@title='Faded Short Sleeve T-shirts'])[2]")
	public static WebElement product;
	
	@FindBy(xpath = "//*[contains(@title, 'Add to cart')]")
	public static WebElement addToCart;
	
	@FindBy(partialLinkText = "Proceed to checkout")
	public static WebElement checkout;
	
	@FindBy(xpath = "//button[@name='processAddress']//span[contains(text(),'Proceed to checkout')]")
	public static WebElement addresscheckout;
	
	@FindBy(xpath = "//button[@name='processCarrier']//span[contains(text(),'Proceed to checkout')]")
	public static WebElement shippingcheckout;
	
	@FindBy(id = "cgv")
	public static WebElement termsOfService;
	
	@FindBy(xpath = "//*[@id=\"cart_navigation\"]/button")
	public static WebElement confirm;

	@FindBy(xpath = "//*[contains(text(),'Your order on My Store')]")
	public static WebElement order;

	@FindBy(xpath = "//*[contains(@title, 'Pay by bank wire')]")
	public static WebElement payment;
	
	@FindBy(id = "email")
	public static WebElement loginUserName;
	

	public productCheckoutPage() {
		PageFactory.initElements(driver, this);
	}

	public static WebElement getSignin() {
		return signin;
	}

	public static void setSignin(WebElement signin) {
		productCheckoutPage.signin = signin;
	}
	
	public static WebElement getSignOut() {
		return SignOut;
	}

	public static WebElement getEmail_textbox() {
		return email_textbox;
	}

	public static void setEmail_textbox(WebElement email_textbox) {
		productCheckoutPage.email_textbox = email_textbox;
	}	

	public static WebElement getLoginUserName() {
		return loginUserName;
	}

	public static void setLoginUserName(WebElement loginUserName) {
		productCheckoutPage.loginUserName = loginUserName;
	}

	public static WebElement getPasswd() {
		return passwd;
	}

	public static void setPasswd(WebElement passwd) {
		productCheckoutPage.passwd = passwd;
	}

	public static WebElement getSubmitLogin() {
		return SubmitLogin;
	}

	public static void setSubmitLogin(WebElement submitLogin) {
		SubmitLogin = submitLogin;
	}

	public static WebElement gettShirt() {
		return tShirt;
	}

	public static void settShirt(WebElement tShirt) {
		productCheckoutPage.tShirt = tShirt;
	}

	public static WebElement getProduct() {
		return product;
	}

	public static void setProduct(WebElement product) {
		productCheckoutPage.product = product;
	}

	public static WebElement getAddToCart() {
		return addToCart;
	}

	public static void setAddToCart(WebElement addToCart) {
		productCheckoutPage.addToCart = addToCart;
	}

	public static WebElement getCheckout() {
		return checkout;
	}

	public static WebElement getaddressCheckout() {
		return addresscheckout;
	}

	public static WebElement getshippingCheckout() {
		return shippingcheckout;
	}

	public static void setCheckout(WebElement checkout) {
		productCheckoutPage.checkout = checkout;
	}	

	public static WebElement getConfirm() {
		return confirm;
	}

	public static void setConfirm(WebElement confirm) {
		productCheckoutPage.confirm = confirm;
	}

	public static WebElement getOrder() {
		return order;
	}

	public static void setOrder(WebElement order) {
		productCheckoutPage.order = order;
	}

	public static WebElement getPayment() {
		return payment;
	}

	public static void setPayment(WebElement payment) {
		productCheckoutPage.payment = payment;
	}

	public static WebElement getTermsOfService() {
		return termsOfService;
	}

	public static void setTermsOfService(WebElement termsOfService) {
		productCheckoutPage.termsOfService = termsOfService;
	}

}
