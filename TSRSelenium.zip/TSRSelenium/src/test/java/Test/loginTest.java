package Test;

import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import pages.base;
import pages.loginPage;

public class loginTest extends base{
	
	String fake_mailid; 
	static ExtentTest test;
	static ExtentReports report;
	
	@Parameters({ "browser" })
	@BeforeClass
	public void beforeClass(String s1) {
		launchBrowser(s1);
		report = new ExtentReports(System.getProperty("user.dir")+"\\ExtentReportResults.html");
		test = report.startTest("ExtentDemo");
	}

	@BeforeMethod
	public void startTime() {
		Date d = new Date();
		System.out.println(d);
	}
	
	@BeforeTest
	public void beforetest() {
		Faker faker = new Faker();
		this.fake_mailid = faker.internet().emailAddress();
	}

	@DataProvider(name = "data-provider")
	public Object[][] dpMethod() {
		return new Object[][] { { "http://automationpractice.com/index.php", fake_mailid, "Rajendran",
				"Krishnamurthy", "raju123", "Hexaware", "123, ABC Street", "VM Road", "pblr", "00000", "add info",
				"088-4847499", "7484937989" } };
	}	

	@Parameters({ "url", "usName", "pasword" })
	@Test(priority = 2)
	public void login(String url, String s1, String s2) {
		new loginPage();
		try {
			getUrl(url);
			Assert.assertTrue(driver.getCurrentUrl().equals(url));
			test.log(LogStatus.PASS, "Login: Navigated to the Login URL");	
			btnClick(loginPage.getSignin());
			type(loginPage.getLoginUserName(), s1);
			type(loginPage.getPasswd(), s2);
			btnClick(loginPage.getSubmitLogin());
			test.log(LogStatus.PASS, "Login: User is Logged in successfully!");
			btnClick(loginPage.getSignOut());
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	

	@AfterMethod
	public void endTime() {
		Date d = new Date();
		System.out.println(d);
	}

	@AfterClass
	public void closeBrowser() {
		report.endTest(test);
		report.flush();
		quitBrowser();
	}

}
