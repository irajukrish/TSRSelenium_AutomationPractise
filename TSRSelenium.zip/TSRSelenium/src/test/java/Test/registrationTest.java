package Test;

import java.util.Date;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import pages.base;
import pages.registrationPage;

public class registrationTest extends base{
	
	String fake_mailid; 
	static ExtentTest test;
	static ExtentReports report;
	
	@Parameters({ "browser" })
	@BeforeClass
	public void beforeClass(String s1) {
		launchBrowser(s1);
		report = new ExtentReports(System.getProperty("user.dir")+"\\ExtentReportResults.html");
		test = report.startTest("ExtentDemo");
	}

	@BeforeMethod
	public void startTime() {
		Date d = new Date();
		System.out.println(d);
	}
	
	@BeforeTest
	public void beforetest() {
		Faker faker = new Faker();
		this.fake_mailid = faker.internet().emailAddress();
	}

	@DataProvider(name = "data-provider")
	public Object[][] dpMethod() {
		return new Object[][] { { "http://automationpractice.com/index.php", fake_mailid, "Rajendran",
				"Krishnamurthy", "raju123", "Hexaware", "123, ABC Street", "VM Road", "pblr", "00000", "add info",
				"088-4847499", "7484937989" } };
	}

	@Test(dataProvider = "data-provider", priority = 1)
	public void Registration(String url, String email, String fName, String lName, String pass, String company,
			String add1, String add2, String city, String postal, String addInfo, String hPhone, String mobPhone)
			throws InterruptedException {
		try {
			new registrationPage();
			getUrl(url);
			Assert.assertTrue(driver.getCurrentUrl().equals(url));
			test.log(LogStatus.PASS, "Registration: Navigated to the Login URL");			
			btnClick(registrationPage.getSignin());
			mouseHover(registrationPage.getCreateAnAccount());
			type(registrationPage.getEmail_textbox(), email);
			btnClick(registrationPage.getCreateAnAccount());
			Thread.sleep(5000);
			btnClick(registrationPage.getTitle());
			type(registrationPage.getfName(), fName);
			type(registrationPage.getlName(), lName);
			type(registrationPage.getPassword(), pass);
			selectByValue(registrationPage.getDay(), "5");
			selectByValue(registrationPage.getMonths(), "5");
			selectByValue(registrationPage.getYears(), "2020");
			type(registrationPage.getCompany(), company);
			type(registrationPage.getAddress(), add1);
			type(registrationPage.getAdd2(), add2);
			type(registrationPage.getCity(), city);
			selectByText(registrationPage.getState(), "Alaska");
			type(registrationPage.getPostcode(), postal);
			selectByValue(registrationPage.getCountry(), "21");
			type(registrationPage.getOther(), addInfo);
			type(registrationPage.getPhone(), hPhone);
			type(registrationPage.getPhone_mobile(), mobPhone);
			btnClick(registrationPage.getSubmitAccount());
			test.log(LogStatus.PASS, "Registration: Successfully completed the registration");
			btnClick(registrationPage.getSignOut());

		} catch (Exception e) {
			e.printStackTrace();
		}

	}	

	@AfterMethod
	public void endTime() {
		Date d = new Date();
		System.out.println(d);
	}

	@AfterClass
	public void closeBrowser() {
		report.endTest(test);
		report.flush();
		quitBrowser();
	}

}
